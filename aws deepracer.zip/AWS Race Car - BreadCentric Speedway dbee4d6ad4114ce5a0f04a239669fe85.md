# AWS Race Car - BreadCentric Speedway

# Challenge Details

---

- Machine learning Type: Reinforcement learning
- The model wants to maximize the total reward at every full lap

# All modifiable

---

- Track directions
    - CW
    - CCW
- Learning Type
    - PPO
    - ACT: doesn’t works, keeps waiting
- Episode Learning Duration
    - Up to 10hr
- Parameters
    - Fixed - Environment
        1. "track_length": float, *track length in meters.*
        2. "track_width": float, *width of the track*
    - Agent
        1. all_wheels_on_track": Boolean,  *flag to indicate if the agent is on the track*
        2. "is_offtrack": Boolean, *Boolean flag to indicate whether the agent has gone off track.*
        3. "distance_from_center": float, *distance in meters from the track center*
        4. "is_left_of_center": Boolean, Flag to indicate if the agent is left side to track center
        5. "steering_angle": float, *agent's steering angle in degrees*
        6. "progress": float, *percentage of track completed*
        7. "steps": int, *number steps completed*
        8. "speed": float, *agent's speed in meters per second (m/s)*
    - Complicated but doable
        1. "x": float, *agent's x-coordinate in meters*
        2. "y": float, *agent's y-coordinate in meters*
        3. "heading": float, *agent's yaw in degrees*
        4. "is_reversed": Boolean, flag to indicate if the agent is driving CW (T) or CCW (F).
        5. "closest_waypoints": [int, int], *indices of the two nearest waypoints.*
        6. "waypoints": [(float, float), ] *list of (x,y) as milestones along the track center*

# Reward function code template

---

```python
import math
# import random
# import numpy
# import scipy
# import shapely

def reward_function(params):
    # Example of rewarding the agent to ---

    # Read input parameters
    #Boolean,  flag to indicate if the agent is on the track
    all_wheels_on_track = params['all_wheels_on_track']
    #float, agent's x-coordinate in meters
    x = params['x']
    #float, agent's y-coordinate in meters
    y = params['y']
    #[int, int], zero-based indices of the two closest objects to the agent's current position of (x, y).
    closest_objects_1, closest_objects_2 = params['closest_objects']
    #[int, int], indices of the two nearest waypoints.
    closest_waypoints_1, closest_waypoints_2 = params['closest_waypoints']
    #float, distance in meters from the track center
    distance_from_center = params['distance_from_center'] 
    #Boolean, Flag to indicate if the agent is on the left side to the track center or not.
    is_left_of_center = params['is_left_of_center']
    #Boolean, Boolean flag to indicate whether the agent has gone off track.
    is_offtrack = params['is_offtrack']
    #Boolean, flag to indicate if the agent is driving clockwise (True) or counter clockwise (False).
    is_reversed = params['is_reversed']
    #float, agent's yaw in degrees
    heading = params['heading']
    #float, percentage of track completed
    progress = params['progress']
    #float, agent's speed in meters per second (m/s)
    speed = params['speed']
    #float, agent's steering angle in degrees
    steering_angle = params['steering_angle']
    #int, number steps completed
    steps = params['steps']
    #float, track length in meters.
    track_length = params['track_length']
    #float, width of the track
    track_width = params['track_width']
    #[(float, float), ] list of (x,y) as milestones along the track center
    waypoints = params['waypoints']

    reward = 5

    return float(reward)
```

# General Tips & Brainstorming

---

- You can use rewards/penalities as multiplication factor — the closer to the center the higher the reward
- Don’t be too complicted
- Don’t be too vague — make the model know what it’s being rewarded for.
- progress vs pointing the steering to the center of a few waypoints down the track
- you can use waypoints to reward/punish certain behavior temporarily only at a specific part of the route
- Make incremental changes: make sure it can stay on the track before increasing its speed
- Rewards:
    - Staying in the right lane (number of right turns > number of left)
    - All wheels on track
    - Good progress
- Discounts
    - steering angle more than abs(20)
    - Overall time - 0.8x
    - completely off track

## Examples

- All wheels on track
    
    ```python
    def reward_function(params):
        #############################################################################
        '''
        Example of using all_wheels_on_track and speed
        '''
    
        # Read input variables
        all_wheels_on_track = params['all_wheels_on_track']
        speed = params['speed']
    
        # Set the speed threshold based your action space
        SPEED_THRESHOLD = 1.0
    
        if not all_wheels_on_track:
            # Penalize if the car goes off track
            reward = 1e-3
        elif speed < SPEED_THRESHOLD:
            # Penalize if the car goes too slow
            reward = 0.5
        else:
            # High reward if the car stays on track and goes fast
            reward = 1.0
    
        return float(reward)
    ```
    
- Waypoints
    
    ```python
    # Place import statement outside of function (supported libraries: math, random, numpy, scipy, and shapely)
    # Example imports of available libraries
    #
    # import math
    # import random
    # import numpy
    # import scipy
    # import shapely
    
    import math
    
    def reward_function(params):
        ###############################################################################
        '''
        Example of using waypoints and heading to make the car point in the right direction
        '''
    
        # Read input variables
        waypoints = params['waypoints']
        closest_waypoints = params['closest_waypoints']
        heading = params['heading']
    
        # Initialize the reward with typical value
        reward = 1.0
    
        # Calculate the direction of the center line based on the closest waypoints
        next_point = waypoints[closest_waypoints[1]]
        prev_point = waypoints[closest_waypoints[0]]
    
        # Calculate the direction in radius, arctan2(dy, dx), the result is (-pi, pi) in radians
        track_direction = math.atan2(next_point[1] - prev_point[1], next_point[0] - prev_point[0])
        # Convert to degree
        track_direction = math.degrees(track_direction)
    
        # Calculate the difference between the track direction and the heading direction of the car
        direction_diff = abs(track_direction - heading)
        if direction_diff > 180:
            direction_diff = 360 - direction_diff
    
        # Penalize the reward if the difference is too large
        DIRECTION_THRESHOLD = 10.0
        if direction_diff > DIRECTION_THRESHOLD:
            reward *= 0.5
    
        return float(reward)
    
    ```
    
- Distance to center
    
    ```python
    def reward_function(params):
        #################################################################################
        '''
        Example of using distance from the center
        '''
    
        # Read input variable
        track_width = params['track_width']
        distance_from_center = params['distance_from_center']
    
        # Penalize if the car is too far away from the center
        marker_1 = 0.1 * track_width
        marker_2 = 0.5 * track_width
    
        if distance_from_center <= marker_1:
            reward = 1.0
        elif distance_from_center <= marker_2:
            reward = 0.5
        else:
            reward = 1e-3  # likely crashed/ close to off track
    
        return float(reward)
    ```
    
- Zigzag (yaw)
    
    ```python
    def reward_function(params):
        # Example of penalize steering, which helps mitigate zig-zag behaviors
    
        # Read input parameters
        distance_from_center = params['distance_from_center']
        track_width = params['track_width']
        abs_steering = abs(params['steering_angle']) # Only need the absolute steering angle
    
        # Calculate 3 marks that are farther and father away from the center line
        marker_1 = 0.1 * track_width
        marker_2 = 0.25 * track_width
        marker_3 = 0.5 * track_width
    
        # Give higher reward if the car is closer to center line and vice versa
        if distance_from_center <= marker_1:
            reward = 1.0
        elif distance_from_center <= marker_2:
            reward = 0.5
        elif distance_from_center <= marker_3:
            reward = 0.1
        else:
            reward = 1e-3  # likely crashed/ close to off track
    
        # Steering penality threshold, change the number based on your action space setting
        ABS_STEERING_THRESHOLD = 15 
        
        # Penalize reward if the car is steering too much
        if abs_steering > ABS_STEERING_THRESHOLD:
            reward *= 0.8
            
        return float(reward)
    ```
    
- Progress & steps
    
    ```python
    def reward_function(params):
        #############################################################################
        '''
        Example of using steps and progress
        '''
    
        # Read input variable
        steps = params['steps']
        progress = params['progress']
    
        # Total num of steps we want the car to finish the lap, it will vary depends on the track length
        TOTAL_NUM_STEPS = 300
    
        # Initialize the reward with typical value
        reward = 1.0
    
        # Give additional reward if the car pass every 100 steps faster than expected
        if (steps % 100) == 0 and progress > (steps / TOTAL_NUM_STEPS) * 100 :
            reward += 10.0
    
        return float(reward)
    ```
    
- Inside borders
    
    ```python
    def reward_function(params):
        #############################################################################
        '''
        Example of using track width
        '''
    
        # Read input variable
        track_width = params['track_width']
        distance_from_center = params['distance_from_center']
    
        # Calculate the distance from each border
        distance_from_border = 0.5 * track_width - distance_from_center
    
        # Reward higher if the car stays inside the track borders
        if distance_from_border >= 0.05:
            reward = 1.0
        else:
            reward = 1e-3 # Low reward if too close to the border or goes off the track
    
        return float(reward)
    ```
    

# Trials

---

- Right Lane -  Capitalist
    - Learning Duration: 1hr
    - Strategy
        - Rewards
            - Staying in the right lane (number of right turns > number of left)
            - All wheels on track
        - Punishments
            - steering angle more than abs(15)
        - Code
            
            ```python
            def reward_function(params):
                # Example of rewarding the agent to stay inside the two borders of the track
                
                # Read input parameters
                #Boolean,  flag to indicate if the agent is on the track
                all_wheels_on_track = params['all_wheels_on_track']
                #float, distance in meters from the track center
                distance_from_center = params['distance_from_center'] 
                #Boolean, Flag to indicate if the agent is left side to track center
                is_left_of_center = params['is_left_of_center']
                #Boolean, Boolean flag to indicate whether the agent has gone off track.
                is_offtrack = params['is_offtrack']
                #Boolean, flag to indicate if the agent is driving CW (T) or CCW (F).
                is_reversed = params['is_reversed']
                #float, agent's yaw in degrees
                heading = params['heading']
                #float, percentage of track completed
                progress = params['progress']
                #float, agent's speed in meters per second (m/s)
                speed = params['speed']
                #float, agent's steering angle in degrees
                steering_angle = params['steering_angle']
                #int, number steps completed
                steps = params['steps']
                #float, track length in meters.
                track_length = params['track_length']
                #float, width of the track
                track_width = params['track_width']
                
                # Give a very low reward by default
                reward = 1e-3
            
                # Give a high reward if no wheels go off the track and
                # the agent is somewhere in between the track borders
                if (not all_wheels_on_track):
                    reward = 1e-3
                else:
                    reward = 2
                    if (not is_left_of_center):
                        reward += 0.5
                    if (abs(steering_angle)>20):
                        reward -= 0.1
            
                # Always return a float value
                return float(reward)
            ```
            
    - Feedback - in order of significance
        1. Can’t handle sudden turns.
        2. Slight zigzag
        3. Slow
- Way points - Smart
    - Training: 2hr
    - Strategy
        - Reward:
            - Angle of heading is the angle of the upcoming waypoint (within 10deg range)
        - Punish:
            - Off track
            - speed <1
    - Code
        
        ```python
        import math
        
        def reward_function(params):
            
            # Read input variables
            waypoints = params['waypoints']
            closest_waypoints = params['closest_waypoints']
            heading = params['heading']
            all_wheels_on_track = params['all_wheels_on_track']
        	
            # Initialize the reward with typical value
            reward = 1
            if (all_wheels_on_track):
                reward = 1.0
            else:
                reward = 1e-3
        
            # Calculate the direction of the center line based on the closest waypoints
            diff = abs(closest_waypoints[1]-len(waypoints))
            if (diff>=4):
                point_after_next = (closest_waypoints[1]+3)
            else:
                point_after_next = 4 - diff
            
            next_point = waypoints[point_after_next]
            prev_point = waypoints[closest_waypoints[0]]
        
            # Calculate the direction in radius, arctan2(dy, dx), the result is (-pi, pi) in radians
            track_direction = math.atan2(next_point[1] - prev_point[1], next_point[0] - prev_point[0])
            # Convert to degree
            track_direction = math.degrees(track_direction)
        
            # Calculate the difference between the track direction and the heading direction of the car
            direction_diff = abs(track_direction - heading)
            if direction_diff > 180:
                direction_diff = 360 - direction_diff
        
            # Penalize the reward if the difference is too large
            DIRECTION_THRESHOLD = 10.0
            if direction_diff > DIRECTION_THRESHOLD:
                reward *= 0.5
        
            return float(reward)
        ```
        
        ```python
        import math
        
        def reward_function(params):
            ###############################################################################
            '''
            Example of using waypoints and heading to make the car point in the right direction
            '''
        
            # Read input variables
            waypoints = params['waypoints']
            closest_waypoints = params['closest_waypoints']
            heading = params['heading']
            all_wheels_on_track = params['all_wheels_on_track']
            x = params['x']
            y = params['y']
            speed = params['speed']
        
            # Initialize the reward with typical value
            if (all_wheels_on_track and speed>1):
                reward = 1.0
            else:
                reward = 1e-3
        
            # Calculate the direction of the center line based on the closest waypoints
            if (closest_waypoints[1]==(len(waypoints)-1)):
                point_after_next = 0
            else:
                point_after_next = (closest_waypoints[1]+1)
            
            next_point = waypoints[point_after_next]
        
            # Calculate the direction in radius, arctan2(dy, dx), the result is (-pi, pi) in radians
            track_direction = math.atan2(next_point[1] - y, next_point[0] - x)
            # Convert to degree
            track_direction = math.degrees(track_direction)
        
            # Calculate the difference between the track direction and the heading direction of the car
            direction_diff = abs(track_direction - heading)
            if direction_diff > 180:
                direction_diff = 360 - direction_diff
        
            # Penalize the reward if the difference is too large
            DIRECTION_THRESHOLD = 10.0
            if direction_diff > DIRECTION_THRESHOLD:
                reward *= 0.5
        
            return float(reward)
        ```
        
    - Results
        - Slow
        - Zigzag
        - On track 100%
- Progress - Adventurer
    - Training: 3hr
    - Motivation: My quote is “Not all those who wander are lost.” Just like I want to experiment with my life till I find my own unique path that works for me to achieve my life purpose, the robot must want that for itself too. So, the robot is only given a final purpose: “Complete the episode in 55 seconds or less.”
    - Strategy:
        - Reward: when the current progress is equal to or larger than how it would perform if it finishes the lap in 55 s (total steps = 55*15 = 825)
    - Recommendations:
        - Better way to phrase that life purpose (exponential? per final lap count?)
        - Punish if out of the track (you’re too lost my son)
    - Feedback
        - Works better than any of the other techniques (maybe because longer training? the others did a better job stabilizing tho)
        - unstable
        - goes out a lot
    - Code
        
        ```python
        def reward_function(params):
            #############################################################################
            '''
            Example of using steps and progress
            '''
        
            # Read input variable
            steps = params['steps']
            progress = params['progress']
            all_wheels_on_track = params['all_wheels_on_track']
        
            # Total num of steps we want the car to finish the lap, it will vary depends on the track length
            TOTAL_NUM_STEPS = 850
        
            # Initialize the reward with typical value
            reward = 1.0
        
            # Give additional reward if the car pass every 100 steps faster than expected
            if ((steps <= ((progress*TOTAL_NUM_STEPS)/100)) and all_wheels_on_track):
                reward = 50
        
            return float(reward)
        ```
        

# Resources

---

/